import json

def handler(event, context):
    response = {
        'statusCode': 200,
        'body': 'Hello, World!'
    }
    return response
